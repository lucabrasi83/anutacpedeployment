"""
Copyright 2015, Rob Shakir (rjs@jive.com, rjs@rob.sh)

This project has been supported by:
          * Jive Communcations, Inc.
          * BT plc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import copy
import xml.etree.ElementTree as ET
import json
from yangtypes import is_yang_leaflist
from servicemodel import untangle


def order_buffer(buf):
  tree = ET.fromstring(buf)
  leaf_childs = []
  nonleaf_childs = []

  for child in tree:
    if bool(child.text):
      leaf_childs.append(child)
    else:
      nonleaf_childs.append(child)

  #for new tree
  newtree = ET.Element(tree.tag, tree.attrib)
  for leaf in leaf_childs:
    newtree.append(leaf)

  for nonleaf in nonleaf_childs:
    newtree.append(nonleaf)

  return ET.tostring(newtree)

def order_buffer(buf):
  tree = untangle.parse(buf)
  leaf_childs = []
  nonleaf_childs = []

  for child in tree.children[0].children:
    if child.cdata != '':
      leaf_childs.append(child)
    else:
      nonleaf_childs.append(child)

  #for new tree
  newtree = untangle.Element(tree.children[0]._name, tree.children[0]._xmlname, tree.children[0]._attributes)
  #leaf ordering is done during binding generation keys are first in the list
  #leaf_childs.reverse()
  for leaf in leaf_childs:
    newtree.add_child(leaf)

  for nonleaf in nonleaf_childs:
    newtree.add_child(nonleaf)

  return newtree.toXml()

def trim_xpath(xpath):
  xpathlist = xpath.split('/')
  xpathlist_trimmed = []
  lmname = xpathlist[0].split(':')[0]
  xpathlist_trimmed.append(xpathlist[0])
  for xp in xpathlist[1:]:
    if xp.split(':')[0] == lmname:
      xpathlist_trimmed.append(xp.split(':')[-1])
    else:
      if len(xp.split(':')) > 1:
        lmname = xp.split(':')[0]
      xpathlist_trimmed.append(xp)
  xpath_new = "/".join(xpathlist_trimmed)
  return xpath_new

def make_device_dict(node, form_dict, parent_xpath):
  form_dict['xpath'] = '%s/%s:%s'%(parent_xpath, node.attrib['module'], node.tag)
  form_dict['xpath'] = trim_xpath(form_dict['xpath'])

  form_dict['fields'] = {}
  fields =  form_dict['fields']

  #form fields dict (leafs)
  for child in node:
    if bool(child.attrib) == False:
      fields['%s'%child.tag] = ['%s'%child.text]

  form_dict['children'] = {}
  children =  form_dict['children']

  #form child dict (non leafs)
  for child in node:
    if bool(child.attrib) == True:
      recur_dict = {}
      if children.get(child.tag) is not None:
        children['%s'%child.tag].append(recur_dict)
      else:
        children['%s'%child.tag] = [recur_dict]
      make_device_dict(child, recur_dict, form_dict.get('xpath'))

class PybindBase(object):

  __slots__ = ()

  def elements(self):
    return self._pyangbind_elements

  def __str__(self):
    return str(self.elements())

  def get(self, filter=False):
    def error():
      return NameError, "element does not exist"
    d = {}
    # for each YANG element within this container.
    for element_name in self._pyangbind_elements:
      element = getattr(self, element_name, error)
      if hasattr(element, "yang_name"):
        # retrieve the YANG name method
        yang_name = getattr(element, "yang_name", error)
        element_id = yang_name()
      else:
        element_id = element_name
      if hasattr(element, "get"):
        # this is a YANG container that has its own
        # get method
        d[element_id] = element.get(filter=filter)
        if filter is True:
          # if the element hadn't changed but we were
          # filtering unchanged elements, remove it
          # from the dictionary
          if isinstance(d[element_id], dict):
            for entry in d[element_id]:
              if hasattr(d[element_id][entry], "_changed"):
                if not d[element_id][entry]._changed():
                  del d[element_id][entry]
            if len(d[element_id]) == 0:
              del d[element_id]
          elif isinstance(d[element_id], list):
            for list_entry in d[element_id]:
              if hasattr(list_entry, "_changed"):
                if not list_entry._changed():
                  d[element_id].remove(list_entry)
            if len(d[element_id]) == 0:
              del d[element_id]
      else:
        # this is an attribute that does not have get()
        # method
        if filter is False and not element._changed():
          if element._default is not False and element._default:
            d[element_id] = element._default
          else:
            d[element_id] = element
        elif element._changed():
          d[element_id] = element
        else:
          # changed = False, and filter = True
          pass
    return d

  def getdevicexml(self, filter=False):
    def error():
      return NameError, "element does not exist"
    d = {}
    buf = ''
    # for each YANG element within this container.
    for element_name in self._pyangbind_elements:
      element = getattr(self, element_name, error)
      if hasattr(element, "yang_name"):
        # retrieve the YANG name method
        yang_name = getattr(element, "yang_name", error)
        element_id = yang_name()
      else:
        element_id = element_name
      if hasattr(element, "getdevicexml"):
        buf += '%s' % (element.getdevicexml(filter=filter))
        # removing empty yangbase class tags
        buf = buf.replace('<YANGBaseClass></YANGBaseClass>', '')
      else:
        # this is an attribute that does not have getdevicexml()
        # method
        temp_buf = ''

        if filter is False and not element._changed():
          if element._default is not False and element._default:
            d[element_id] = element._default
            temp_buf = '<%s>%s</%s>' % (element_id, element._default, element_id)  
          else:
            d[element_id] = element
            temp_buf = '<%s>%s</%s>' % (element_id, element, element_id)
        elif element._empty_tag:
            temp_buf += '<%s/>' % (element_id)             
        elif element._changed():
          d[element_id] = element
          if is_yang_leaflist(element):
            for item in element:
              temp_buf += '<%s>%s</%s>' % (element_id, item, element_id)
          else:
            temp_buf += '<%s>%s</%s>' % (element_id, element, element_id)
        else:
          # changed = False, and filter = True
          pass

        # cheking for boolean types and converting hte values appropriately
        if element._yang_type == 'boolean' and element._is_leaf:
          buf += temp_buf.replace('>True', '>true').replace('>False', '>false')
        else:
          buf += temp_buf

    if buf != '':
      if hasattr(self, "yang_name"):
        # retrieve the YANG name method
        if hasattr(self, "_module_name"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self.yang_name(), self._module_name, self._is_container, buf, self.yang_name())
        elif hasattr(self, "_defining_module"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self.yang_name(), self._defining_module, self._is_container, buf, self.yang_name())
      elif hasattr(self, "_yang_name"):
        # retrieve the YANG name method
        if hasattr(self, "_module_name"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self._yang_name, self._module_name, self._pybind_generated_by, buf, self._yang_name)
        elif hasattr(self, "_defining_module"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self._yang_name, self._defining_module, self._pybind_generated_by, buf, self._yang_name)
      else:
        if hasattr(self, "_module_name"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self.__class__.__name__.replace('_', '-'), self._module_name, self.is_container, buf ,self.__class__.__name__.replace('_', '-'))
        elif hasattr(self, "_defining_module"):
          buf = '<%s module=\"%s\" yang_type=\"%s\">%s</%s>' % (self.__class__.__name__.replace('_', '-'), self._defining_module, self.is_container, buf ,self.__class__.__name__.replace('_', '-'))
    return buf  

  def get_rest_url(self, filter=False):
    return None

  def getxml(self, filter=False, netconf=False, recur=False):
    if netconf:
      filter = netconf

    def error():
      return NameError, "element does not exist"
    d = {}
    buf = ''
    # for each YANG element within this container.
    for element_name in self._pyangbind_elements:
      element = getattr(self, element_name, error)
      if hasattr(element, "yang_name"):
        # retrieve the YANG name method
        yang_name = getattr(element, "yang_name", error)
        element_id = yang_name()
      else:
        element_id = element_name
      if not hasattr(element, "getxml"):
        # this is an attribute that does not have getxml()
        # method
        temp_buf = ''

        if filter is False and not element._changed():
          if element._default is not False and element._default:
            d[element_id] = element._default
            if element._defining_module == self._module_name:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element._default, element._metadata['_netconf_operation_type'])
                else:
                  temp_buf = '<%s>%s</%s>' % (element_id, element._default, element_id)  
              else:
                temp_buf = '<%s>%s</%s>' % (element_id, element._default, element_id)  
            else:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element._default, element._metadata['_netconf_operation_type'], element._defining_module)
                else:
                  temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element._default, element._defining_module)
              else:
                temp_buf += '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(element._defining_module, element_id, element._namespace, element._default)
          else:
            d[element_id] = element
            if element._defining_module == self._module_name:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element, element._metadata['_netconf_operation_type'])
                else:
                  temp_buf = '<%s>%s</%s>' % (element_id, element, element_id)
              else:
                temp_buf = '<%s>%s</%s>' % (element_id, element, element_id)
            else:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element, element._metadata['_netconf_operation_type'], element._defining_module)
                else:
                  temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element, element._defining_module)
              else:
                temp_buf += '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(element._defining_module, element_id, element._namespace, element)
        elif element._empty_tag:
            if element._defining_module == self._module_name:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{0} operation=\"{1}\"/>'.format(element_id, element._metadata['_netconf_operation_type'])
                else:
                  temp_buf += '<%s/>' % (element_id)
              else:
                temp_buf += '<%s/>' % (element_id)
            else:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\" operation=\"{2}\"/>'.format(element_id, element._namespace, element._metadata['_netconf_operation_type'], element._defining_module)
                else:
                  temp_buf += '<{2}:{0} xmlns:{2}=\"{1}\"/>'.format(element_id, element._namespace, element._defining_module)
              else:
                temp_buf += '<{0}:{1} xmlns:{0}=\"{2}\"/>'.format(element._defining_module, element_id, element._namespace)
        elif element._changed():
          d[element_id] = element
          if is_yang_leaflist(element):
            for item in element:
              if element._defining_module == self._module_name:
                if netconf:
                  if hasattr(item, '_metadata') and item._metadata.get("_netconf_operation_type") is not None:
                    temp_buf += '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, item, element._metadata['_netconf_operation_type'])
                  else:
                    temp_buf += '<%s>%s</%s>' % (element_id, item, element_id)
                else:
                  temp_buf += '<%s>%s</%s>' % (element_id, item, element_id)
              else:
                if netconf:
                  if hasattr(item, '_metadata') and item._metadata.get("_netconf_operation_type") is not None:
                    temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, item, item._metadata['_netconf_operation_type'], element._defining_module)
                  else:
                    temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, item, element._defining_module)
                else:
                  temp_buf += '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(element._defining_module, element_id, element._namespace, item)
          else:
            if element._defining_module == self._module_name:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element, element._metadata['_netconf_operation_type'])
                else:
                  temp_buf += '<%s>%s</%s>' % (element_id, element, element_id)
              else:
                temp_buf += '<%s>%s</%s>' % (element_id, element, element_id)
            else:
              if netconf:
                if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element, element._metadata['_netconf_operation_type'], element._defining_module)
                else:
                  temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element, element._defining_module)
              else:
                temp_buf += '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(element._defining_module, element_id, element._namespace, element)
        else:
          # changed = False, and filter = True
          pass

        # cheking for boolean types and converting hte values appropriately
        if element._yang_type == 'boolean' and element._is_leaf:
          buf += temp_buf.replace('>True', '>true').replace('>False', '>false')
        else:
          buf += temp_buf
      else:
        buf += '%s' % (element.getxml(filter=filter, netconf=netconf, recur=True))
        # removing empty yangbase class tags
        buf = buf.replace('<YANGBaseClass></YANGBaseClass>', '')

    if buf != '':
      if hasattr(self, "yang_name"):
        # retrieve the YANG name method
        if self._namespace is None or recur == True:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.yang_name(), buf, self._metadata['_netconf_operation_type'])
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.yang_name(), buf, self._netconf_operation_type)
            else:
              buf = '<%s>%s</%s>' % (self.yang_name(), buf, self.yang_name())
          else:
            buf = '<%s>%s</%s>' % (self.yang_name(), buf, self.yang_name())
        else:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.yang_name(), self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.yang_name(), self._namespace, buf, self._netconf_operation_type, element._module_name)
            else:
              buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self.yang_name(), self._namespace, buf, element._module_name)
          else:
            buf = '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(self._module_name, self.yang_name(), self._namespace, buf) 
      elif hasattr(self, "_yang_name"):
        # retrieve the YANG name method
        if self._namespace is None or recur == True:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self._yang_name, buf, self._metadata['_netconf_operation_type'])
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self._yang_name, buf, self._netconf_operation_type)
            else:
              buf = '<%s>%s</%s>' % (self._yang_name, buf, self._yang_name)
          else:
            buf = '<%s>%s</%s>' % (self._yang_name, buf, self._yang_name)
        else:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self._yang_name, self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self._yang_name, self._namespace, buf, self._netconf_operation_type, element._module_name)
            else:
              buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self._yang_name, self._namespace, buf, element._module_name)
          else:
            buf = '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(self._module_name, self._yang_name, self._namespace, buf)
      else:
        if self._namespace is None or recur == True:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.__class__.__name__.replace('_', '-'), buf, self._metadata['_netconf_operation_type'])
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.__class__.__name__.replace('_', '-'), buf, self._netconf_operation_type)
            else:
              buf = '<%s>%s</%s>' % (self.__class__.__name__.replace('_', '-'), buf ,self.__class__.__name__.replace('_', '-'))
          else:
            buf = '<%s>%s</%s>' % (self.__class__.__name__.replace('_', '-'), buf ,self.__class__.__name__.replace('_', '-'))
        else:
          if netconf:
            if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
            elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
              buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, self._netconf_operation_type, element._module_name)
            else:
              buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, element._module_name)
          else:
            buf = '<{0}:{1} xmlns:{0}=\"{2}\">{3}</{0}:{1}>'.format(self._module_name, self.__class__.__name__.replace('_', '-'), self._namespace, buf)
    else:
      if netconf and hasattr(self, '_mchanged') and not self._mchanged and hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
        buf += '<%s operation=\"%s\"/>' % (self._yang_name, self._metadata.get('_netconf_operation_type'))

    #order the elements so that netconf accepts
    if netconf:
      if hasattr(self, '_is_container'):
        if self._is_container == 'list':
          buf = order_buffer(buf)
      elif hasattr(self, '_pybind_generated_by'):
        if self._pybind_generated_by == 'list':
          buf = order_buffer(buf)
      elif hasattr(self, 'is_container'):
        if self.is_container == 'list':
          buf = order_buffer(buf)

    return buf

  def getplainxml(self, recur=False, parent_tag=False):
    filter = True

    def error():
      return NameError, "element does not exist"
    d = {}
    buf = ''
    # for each YANG element within this container.
    for element_name in self._pyangbind_elements:
      element = getattr(self, element_name, error)
      if hasattr(element, "yang_name"):
        # retrieve the YANG name method
        yang_name = getattr(element, "yang_name", error)
        element_id = yang_name()
      else:
        element_id = element_name
      if not hasattr(element, "getplainxml"):
        # this is an attribute that does not have getplainxml()
        # method
        temp_buf = ''

        if filter is False and not element._changed():
          if element._default is not False and element._default:
            d[element_id] = element._default
            temp_buf = '<%s>%s</%s>' % (element_id, element._default, element_id)  
          else:
            d[element_id] = element
            temp_buf = '<%s>%s</%s>' % (element_id, element, element_id)
        elif element._empty_tag:
            temp_buf += '<%s/>' % (element_id)
        elif element._changed():
          d[element_id] = element
          if is_yang_leaflist(element):
            for item in element:
              temp_buf += '<%s>%s</%s>' % (element_id, item, element_id)
          else:
            temp_buf += '<%s>%s</%s>' % (element_id, element, element_id)
        else:
          # changed = False, and filter = True
          pass

        # cheking for boolean types and converting hte values appropriately
        if element._yang_type == 'boolean' and element._is_leaf:
          buf += temp_buf.replace('>True', '>true').replace('>False', '>false')
        else:
          buf += temp_buf
      else:
        buf += '%s' % (element.getplainxml(recur=True))
        # removing empty yangbase class tags
        buf = buf.replace('<YANGBaseClass></YANGBaseClass>', '')

    if buf != '':
      if hasattr(self, "yang_name"):
        # retrieve the YANG name method
        if recur == True or parent_tag:
          buf = '<%s>%s</%s>' % (self.yang_name(), buf, self.yang_name())
      elif hasattr(self, "_yang_name"):
        # retrieve the YANG name method
        if recur == True or parent_tag:
          buf = '<%s>%s</%s>' % (self._yang_name, buf, self._yang_name)
      else:
        if recur == True or parent_tag:
          buf = '<%s>%s</%s>' % (self.__class__.__name__.replace('_', '-'), buf ,self.__class__.__name__.replace('_', '-'))
    else:
      pass

    return buf

  def getnetconfxml(self, recur=False):
    filter = True
    def error():
      return NameError, "element does not exist"
    d = {}
    buf = ''
    # for each YANG element within this container.
    for element_name in self._pyangbind_elements:
      element = getattr(self, element_name, error)
      if hasattr(element, "yang_name"):
        # retrieve the YANG name method
        yang_name = getattr(element, "yang_name", error)
        element_id = yang_name()
      else:
        element_id = element_name
      if not hasattr(element, "getnetconfxml"):
        # this is an attribute that does not have getnetconfxml()
        # method
        temp_buf = ''

        if filter is False and not element._changed():
          if element._default is not False and element._default:
            d[element_id] = element._default
            if element._defining_module == self._module_name:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element._default, element._metadata['_netconf_operation_type'])
              else:
                temp_buf = '<%s>%s</%s>' % (element_id, element._default, element_id)  
            else:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element._default, element._metadata['_netconf_operation_type'], element._defining_module)
              else:
                temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element._default, element._defining_module)
          else:
            d[element_id] = element
            if element._defining_module == self._module_name:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element, element._metadata['_netconf_operation_type'])
              else:
                temp_buf = '<%s>%s</%s>' % (element_id, element, element_id)
            else:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element, element._metadata['_netconf_operation_type'], element._defining_module)
              else:
                temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element, element._defining_module)
        elif element._empty_tag:
            if element._defining_module == self._module_name:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{0} operation=\"{1}\"/>'.format(element_id, element._metadata['_netconf_operation_type'])
              else:
                temp_buf += '<%s/>' % (element_id)
            else:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\" operation=\"{2}\"/>'.format(element_id, element._namespace, element._metadata['_netconf_operation_type'], element._defining_module)
              else:
                temp_buf += '<{2}:{0} xmlns:{2}=\"{1}\"/>'.format(element_id, element._namespace, element._defining_module)
        elif element._changed():
          d[element_id] = element
          if is_yang_leaflist(element):
            for item in element:
              if element._defining_module == self._module_name:
                if hasattr(item, '_metadata') and item._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, item, element._metadata['_netconf_operation_type'])
                else:
                  temp_buf += '<%s>%s</%s>' % (element_id, item, element_id)
              else:
                if hasattr(item, '_metadata') and item._metadata.get("_netconf_operation_type") is not None:
                  temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, item, item._metadata['_netconf_operation_type'], element._defining_module)
                else:
                  temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, item, element._defining_module)
          else:
            if element._defining_module == self._module_name:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{0} operation=\"{2}\">{1}</{0}>'.format(element_id, element, element._metadata['_netconf_operation_type'])
              else:
                temp_buf += '<%s>%s</%s>' % (element_id, element, element_id)
            else:
              if hasattr(element, '_metadata') and element._metadata.get("_netconf_operation_type") is not None:
                temp_buf += '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(element_id, element._namespace, element, element._metadata['_netconf_operation_type'], element._defining_module)
              else:
                temp_buf += '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(element_id, element._namespace, element, element._defining_module)
        else:
          # changed = False, and filter = True
          pass

        # cheking for boolean types and converting hte values appropriately
        if element._yang_type == 'boolean' and element._is_leaf:
          buf += temp_buf.replace('>True', '>true').replace('>False', '>false')
        else:
          buf += temp_buf
      else:
        buf += '%s' % (element.getnetconfxml(recur=True))
        # removing empty yangbase class tags
        buf = buf.replace('<YANGBaseClass></YANGBaseClass>', '')

    if buf != '':
      if hasattr(self, "yang_name"):
        # retrieve the YANG name method
        if self._namespace is None or recur == True:
          if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.yang_name(), buf, self._metadata['_netconf_operation_type'])
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.yang_name(), buf, self._netconf_operation_type)
          else:
            buf = '<%s>%s</%s>' % (self.yang_name(), buf, self.yang_name())
        else:
          if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.yang_name(), self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.yang_name(), self._namespace, buf, self._netconf_operation_type, element._module_name)
          else:
            buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self.yang_name(), self._namespace, buf, element._module_name)
      elif hasattr(self, "_yang_name"):
        # retrieve the YANG name method
        if self._namespace is None or recur == True:
          if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self._yang_name, buf, self._metadata['_netconf_operation_type'])
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self._yang_name, buf, self._netconf_operation_type)
          else:
            buf = '<%s>%s</%s>' % (self._yang_name, buf, self._yang_name)
        else:
          if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self._yang_name, self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self._yang_name, self._namespace, buf, self._netconf_operation_type, element._module_name)
          else:
            buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self._yang_name, self._namespace, buf, element._module_name)
      else:
        if self._namespace is None or recur == True:
          if hasattr(self, '_metadata') and self._metadata.get("_netconf_operation_type") is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.__class__.__name__.replace('_', '-'), buf, self._metadata['_netconf_operation_type'])
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{0} operation=\"{2}\">{1}</{0}>'.format(self.__class__.__name__.replace('_', '-'), buf, self._netconf_operation_type)
          else:
            buf = '<%s>%s</%s>' % (self.__class__.__name__.replace('_', '-'), buf ,self.__class__.__name__.replace('_', '-'))
        else:
          if hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, self._metadata['_netconf_operation_type'], element._module_name)
          elif hasattr(self, '_netconf_operation_type') and self._netconf_operation_type is not None:
            buf = '<{4}:{0} xmlns:{4}=\"{1}\" operation=\"{3}\">{2}</{4}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, self._netconf_operation_type, element._module_name)
          else:
            buf = '<{3}:{0} xmlns:{3}=\"{1}\">{2}</{3}:{0}>'.format(self.__class__.__name__.replace('_', '-'), self._namespace, buf, element._module_name)
    else:
      if hasattr(self, '_mchanged') and not self._mchanged and hasattr(self, '_metadata') and self._metadata.get('_netconf_operation_type') is not None:
        buf += '<%s operation=\"%s\"/>' % (self._yang_name, self._metadata.get('_netconf_operation_type'))

    #order the elements so that netconf accepts
    if hasattr(self, '_is_container'):
      if self._is_container == 'list':
        buf = order_buffer(buf)
    elif hasattr(self, '_pybind_generated_by'):
      if self._pybind_generated_by == 'list':
        buf = order_buffer(buf)
    elif hasattr(self, 'is_container'):
      if self.is_container == 'list':
        buf = order_buffer(buf)

    return buf

  def getdevicejson(self, parent_xpath='/controller:devices/device'):
    dxml = self.getdevicexml(filter=True)
    tree = ET.fromstring(dxml)
    form_dict = {}
    make_device_dict(tree, form_dict, parent_xpath)
    return json.dumps(form_dict)

  def __getitem__(self, k):
    def error():
      raise KeyError("Key %s does not exist" % k)
    element = getattr(self, k, error)
    return element()

  def __iter__(self):
    for elem in self._pyangbind_elements:
      yield (elem, getattr(self, elem))
